package com.lulu.Lulu02_MS1_ReturnsManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lulu02Ms1ReturnsManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lulu02Ms1ReturnsManagementApplication.class, args);
	}

}
