package com.lulu.Lulu02_MS1_ReturnsManagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lulu.Lulu02_MS1_ReturnsManagement.entity.Returns;



public interface ReturnsRepo extends JpaRepository<Returns,Integer > {

}
