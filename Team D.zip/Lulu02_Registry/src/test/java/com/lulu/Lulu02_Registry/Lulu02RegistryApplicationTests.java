package com.lulu.Lulu02_Registry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lulu02RegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
