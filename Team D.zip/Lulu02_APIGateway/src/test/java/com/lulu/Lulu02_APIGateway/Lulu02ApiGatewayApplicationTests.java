package com.lulu.Lulu02_APIGateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lulu02ApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
