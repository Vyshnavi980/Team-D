package com.Lulu02_ProductMaster.Lulu02_ProductMaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lulu02ProductMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lulu02ProductMasterApplication.class, args);
	}

}
