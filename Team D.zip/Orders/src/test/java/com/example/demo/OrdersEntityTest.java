package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;

import com.orders.management.entity.OrdersEntity;
import com.orders.management.entity.PaymentsEntity;
import com.orders.management.entity.ShippingsEntity;
import com.orders.management.repository.OrdersRepo;
import com.orders.management.repository.PaymentsRepo;

	public class OrdersEntityTest {

	    
		//1 
	    @Test
	    public void testCreateOrder() {
	        OrdersEntity ordersEntity = new OrdersEntity();
	        ordersEntity.setOrderid(1);
	        ordersEntity.setDate("01-01-2023");
 
	        // Save the entity to a repository or service
	        // Perform the create operation
 
	        assertNotNull(ordersEntity); // Ensure the entity is not null
	        assertEquals(1, ordersEntity.getOrderid());
	        assertEquals("01-01-2023", ordersEntity.getDate());
 
	        // Additional assertions if needed
	    }

//2
	        @Test
	        public void testReadOrder() {
	            // Retrieve an existing entity from a repository or service
	            OrdersEntity ordersEntity = getEntityFromRepository(); // Replace with actual retrieval
 
	            assertNotNull(ordersEntity); // Ensure the entity is not null
	            assertEquals(1, ordersEntity.getOrderid());
	            assertEquals("01-01-2023", ordersEntity.getDate());
 
	            // Additional assertions if needed
	        }
 
	        // Replace this method with actual retrieval logic
	        private OrdersEntity getEntityFromRepository() {
	            // Implement the logic to retrieve an entity
	        	return new OrdersEntity(1, "01-01-2023");
	        }
//3	        
	        @Test
	            public void testDeleteOrder() {
	                // Retrieve an existing entity from a repository or service
	                OrdersEntity ordersEntity = getEntityFromRepository(); // Replace with actual retrieval
 
	                assertNotNull(ordersEntity); // Ensure the entity is not null
 
	                // Delete the entity from the repository or service
	                deleteEntityFromRepository(ordersEntity); // Replace with actual delete operation
 
	                // Try to retrieve the deleted entity
	            }
 
	            // Replace these methods with actual retrieval and delete logic
	            @SuppressWarnings("unused")
				private OrdersEntity getEntityFromRepository1() {
	                // Implement the logic to retrieve an entity
	                return new OrdersEntity(1, "01-01-2023");
	            }
 
	            private void deleteEntityFromRepository(OrdersEntity entity) {
	                // Implement the logic to delete an entity from the repository or service
	            }
//4	            
	            @Test
	            public void testUpdateOrder() {
	                // Create a mock repository
	                OrdersRepo mockRepository = mock(OrdersRepo.class);
 
	                // Create an initial OrdersEntity
	                OrdersEntity initialOrder = new OrdersEntity(1, "01-01-2023");
 
	                // Define the expected behavior when retrieving an entity
	                when(mockRepository.findById(1)).thenReturn(Optional.of(initialOrder));
 
	                // Retrieve an existing entity from the mock repository
	                OrdersEntity ordersEntity = mockRepository.findById(1).orElse(null);
 
	                assertNotNull(ordersEntity); // Ensure the entity is not null
 
	                // Update the entity
	                ordersEntity.setDate("01-01-2023"); // Replace with the actual update logic
 
	                // Define the expected behavior when saving the updated entity
	                when(mockRepository.save(ordersEntity)).thenReturn(ordersEntity);
 
	                // Perform the update operation in the repository or service
	                OrdersEntity updatedOrder = mockRepository.save(ordersEntity);
 
	                assertNotNull(updatedOrder);
	                assertEquals("01-01-2023", updatedOrder.getDate());
	            }
 
 
	        
//5            
	            //payment
	            @Test
	            public void testCreatePaymentInfo() {
	                PaymentsEntity paymentInfo = new PaymentsEntity();
	                paymentInfo.setInvoiceNo(1);
	                paymentInfo.setPaymentDate("01-01-2023");
	                paymentInfo.setPaymentStatus("Paid");
 
	                // Perform the create operation (e.g., save to a repository or service)
 
	                assertNotNull(paymentInfo); // Ensure the entity is not null
	                assertEquals(1, paymentInfo.getInvoiceNo());
	                assertEquals("01-01-2023", paymentInfo.getPaymentDate());
	                assertEquals("Paid", paymentInfo.getPaymentStatus());
 
	                // Additional assertions if needed
	            }

//6         
	            @Test
	            public void testReadPaymentInfo() {
	                // Create a mock repository
	                PaymentsRepo mockRepository = mock(PaymentsRepo.class);
 
	                // Define the expected behavior when retrieving an entity
	                PaymentsEntity expectedPaymentInfo = new PaymentsEntity();
	                expectedPaymentInfo.setInvoiceNo(1);
	                expectedPaymentInfo.setPaymentDate("01-01-2023");
	                expectedPaymentInfo.setPaymentStatus("Paid");
	                when(mockRepository.findById(1)).thenReturn(Optional.of(expectedPaymentInfo));
 
	                // Retrieve an existing entity from the mock repository
	                PaymentsEntity paymentInfo = mockRepository.findById(1).orElse(null);
 
	                assertNotNull(paymentInfo); // Ensure the entity is not null
	                assertEquals(1, paymentInfo.getInvoiceNo());
	                assertEquals("01-01-2023", paymentInfo.getPaymentDate());
	                assertEquals("Paid", paymentInfo.getPaymentStatus());
 
	                // Additional assertions if needed
	            }
 
	      
//7          
	            @Test
	            public void testUpdatePaymentInfo() {
	                // Create a mock repository
	                PaymentsRepo mockRepository = mock(PaymentsRepo.class);
 
	                // Define the expected behavior when retrieving an entity
	                PaymentsEntity expectedPaymentInfo = new PaymentsEntity();
	                expectedPaymentInfo.setInvoiceNo(1);
	                expectedPaymentInfo.setPaymentDate("01-01-2023");
	                expectedPaymentInfo.setPaymentStatus("Paid");
	                when(mockRepository.findById(1)).thenReturn(Optional.of(expectedPaymentInfo));
 
	                // Retrieve an existing entity from the mock repository
	                PaymentsEntity paymentInfo = mockRepository.findById(1).orElse(null);
 
	                assertNotNull(paymentInfo); // Ensure the entity is not null
	                assertEquals(1, paymentInfo.getInvoiceNo());
	                assertEquals("01-01-2023", paymentInfo.getPaymentDate());
	                assertEquals("Paid", paymentInfo.getPaymentStatus());
 
	                // Update payment status
	                expectedPaymentInfo.setPaymentStatus("Pending");
	                when(mockRepository.save(expectedPaymentInfo)).thenReturn(expectedPaymentInfo);
	                PaymentsEntity updatedPaymentInfo = mockRepository.save(expectedPaymentInfo);
 
	                assertNotNull(updatedPaymentInfo);
	                assertEquals("Pending", updatedPaymentInfo.getPaymentStatus());
	            }
 
//8          
	            @Test
	            public void testDeletePaymentInfo() {
	                // Create a mock repository
	                PaymentsRepo mockRepository = mock(PaymentsRepo.class);
 
	                // Define the expected behavior when retrieving an entity
	                PaymentsEntity expectedPaymentInfo = new PaymentsEntity();
	                expectedPaymentInfo.setInvoiceNo(1);
	                expectedPaymentInfo.setPaymentDate("01-01-2023");
	                expectedPaymentInfo.setPaymentStatus("Paid");
	                when(mockRepository.findById(1)).thenReturn(Optional.of(expectedPaymentInfo));
 
	                // Retrieve an existing entity from the mock repository
	                PaymentsEntity paymentInfo = mockRepository.findById(1).orElse(null);
 
	                assertNotNull(paymentInfo); // Ensure the entity is not null
	                assertEquals(1, paymentInfo.getInvoiceNo());
	                assertEquals("01-01-2023", paymentInfo.getPaymentDate());
	                assertEquals("Paid", paymentInfo.getPaymentStatus());
 
	            }
	            //Shipping
//9
	            @Test
	            public void testCreateShippingInfo() {
	                ShippingsEntity shippingInfo = new ShippingsEntity();
	                shippingInfo.setSid(1);
	                shippingInfo.setS_address("#55 Mg road");
	                shippingInfo.setS_status("Paid");
 
	                // Perform the create operation (e.g., save to a repository or service)
 
	                assertNotNull(shippingInfo); // Ensure the entity is not null
	                assertEquals(1, shippingInfo.getSid());
	                assertEquals("#55 Mg road", shippingInfo.getS_address()); // Corrected the address value
	                assertEquals("Paid", shippingInfo.getS_status());
 
	                // Additional assertions if needed
	            }

	//10            
	            @Test
	            public void testReadShippingInfo() {
	                // Assuming you have a predefined ShippingsEntity with ID 1 in the repository or service
	                ShippingsEntity expectedShippingInfo = new ShippingsEntity();
	                expectedShippingInfo.setSid(1);
	                expectedShippingInfo.setS_address("#55 Mg road");
	                expectedShippingInfo.setS_status("Paid");
 
	               
	                // Additional assertions if needed
	            }
	//11            
	            @Test
	            public void testUpdateShippingInfo() {
	                // Assuming you have a predefined ShippingsEntity with ID 1 in the repository or service
	                ShippingsEntity existingShippingInfo = new ShippingsEntity();
	                existingShippingInfo.setSid(1);
	                existingShippingInfo.setS_address("#55 Mg road");
	                existingShippingInfo.setS_status("Paid");
 
	             
	                // Modify the existing shipping entity
	                existingShippingInfo.setS_address("#75 Brigade road");
	                existingShippingInfo.setS_status("Shipped");
 
	                // Perform the update operation directly on the repository
	            }
//12
	            @Test
	            public void testDeleteShippingInfo() {
	                // Assuming you have a predefined ShippingsEntity with ID 1 in the repository or service
	                ShippingsEntity existingShippingInfo = new ShippingsEntity();
	                existingShippingInfo.setSid(2);
	                existingShippingInfo.setS_address("#55 Mg road");
	                existingShippingInfo.setS_status("Paid");
	            }
 
	    }