package com.lulu.Lulu02_MS1_Products;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lulu02Ms1ProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lulu02Ms1ProductsApplication.class, args);
	}

}
