package com.lulu.Lulu02_MS1_Products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lulu02Ms1ProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
