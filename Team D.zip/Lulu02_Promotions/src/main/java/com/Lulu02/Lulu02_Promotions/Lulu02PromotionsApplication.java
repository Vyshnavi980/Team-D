package com.Lulu02.Lulu02_Promotions;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lulu02PromotionsApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lulu02PromotionsApplication.class, args);
	}

}
