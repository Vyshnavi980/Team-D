package com.Lulu02.Lulu02_Promotions.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Lulu02.Lulu02_Promotions.entity.Promotion;



public interface PromotionRepo extends JpaRepository<Promotion, Integer> {

}
